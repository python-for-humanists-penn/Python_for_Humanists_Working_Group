import os
import re

def load_text(folder, filename):
    path = os.path.join(folder, filename)
    if filename.endswith('.txt'):
        with open(path, encoding='utf-8') as ip:
            return ip.read()
    else:
        return ''


_not_txt_re = re.compile('[^\w]')
def remove_punct(s, _nt=_not_txt_re):
    return _nt.sub(' ', s)
